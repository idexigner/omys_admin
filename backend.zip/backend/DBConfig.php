<?php
 /*
//Define your host here.
$HostName = "localhost";
 
//Define your database name here.
$DatabaseName = "omys_faraz";
 
//Define your database username here.
$HostUser = "root";
 
//Define your database password here.
$HostPass = "";
 

$con = new mysqli($HostName, $HostUser, $HostPass, $DatabaseName);

 */
// //Define your host here.
 $HostName = "omysstudent.com";
 
// //Define your database name here.
 $DatabaseName = "omysstud_omys";
 
// //Define your database username here.
 $HostUser = "omysstud_omys";
 
// //Define your database password here.
 $HostPass = "FarazHassaan786!";
 

 $con = new mysqli($HostName, $HostUser, $HostPass, $DatabaseName);

 
 
?>

