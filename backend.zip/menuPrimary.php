                        <li id="dashboardId">
                            <a class="js-arrow" href="dashboard.php">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                        </li>
                      
                        <li id="createUserId" >
                            <a href="createUser.php">
                                <i class="fas fa-chart-bar"></i>Create User</a>
                        </li>

                        <li id="viewUserId">
                            <a href="viewUser.php">
                                <i class="fas fa-chart-bar"></i>View User</a>
                        </li>

                        <li id="ReportId">
                            <a href="reportPrctc.php">
                                <i class="fas fa-chart-bar"></i>Print Id Card</a>
                        </li>


                        <li id="createStaffId">
                            <a href="createStaff.php">
                                <i class="fas fa-chart-bar"></i>Create Staff</a>
                        </li>
                        <li>
                            <a href="index.php">
                                <i class="fas fa-chart-bar"></i>Logout</a>
                        </li>
                        